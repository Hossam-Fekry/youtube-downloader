from tkinter import *
from tkinter import ttk
import os
from tkinter import filedialog
from pytube import YouTube
from tkinter import messagebox as m_box
import threading

def ask_path():
    download_path.delete(0,END)
    download_file = filedialog.askdirectory(title='video place')
    path.set(download_file)
    


def onClick():
    got_link = link.get()
    got_path = path.get()
    try:
        yt = YouTube(str(got_link))
    except:
        m_box.showerror("Error", "Connection Problem !, please check your internet Connection")
    else:
        statues_bar.config(text='Statuse: Downloading')
        vid = yt.streams.get_highest_resolution()
        destination = str(got_path)
        vid.download(destination)
        os.startfile(got_path)
        statues_bar.config(text = 'Statuse: Complete')
        return m_box.showinfo('Successfully Downloaded.', f"Your YouTube Vidoe Downloaded Successfully at {got_path}/{yt.title}")


threads = []


def startThredProcess():
    myNewThread = threading.Thread(target=onClick)
    threads.append(myNewThread)
    myNewThread.start()

win = Tk()
win.geometry("500x300")
win.title("YouTube Video Downloader")
win.resizable(0,0)
ico = PhotoImage(file='images/download.png')
win.iconphoto(False,ico)
logo = PhotoImage(file='images/logo.png').subsample(8)
Label(win,image=logo).place(y = 10,x = 140)

get_info_link = ttk.Label(win,text="Enter YouTube Video Link : ")
get_info_link.place(x = 5,y = 130)

link = StringVar()

yt_link = ttk.Entry(win, textvariable=link)
yt_link.place(y = 130,x = 155,width = 300)
yt_link.focus()

get_info_path = ttk.Label(win,text="Enter Downloading Path : ")
get_info_path.place(y = 155,x = 5)

path = StringVar()

download_path = ttk.Entry(win,textvariable=path)
download_path.place(x = 155,y = 155,width=250)

browse = ttk.Button(win,text='browse',command=ask_path)
browse.place(y = 152,x = 410)

download = ttk.Button(win,text="Download Video",width=15, command=startThredProcess)
download.place(y=200,x = 225)

statues_bar = Label(win,text = 'Statuse: Ready',bg = 'white',justify='center',font=('itallic'))
statues_bar.pack(side=BOTTOM,fill=X)


win.mainloop()